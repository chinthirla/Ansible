def call(Map params = [:]) {
  // Start Default Arguments
  def args = [
          INIT : true,
          PLAN : false,
          APPLY: true,
          DESTROY: false,
          SERVICE_NAME: "null",
          AWX: false
  ]
  args << params

  if (args.SERVICE_NAME == "null") {
    error("SERVICE_NAME is expected as Input from Jenkinsfile")
  }

  pipeline {
    agent {
      node {
        label 'SLAVE'
      }
    }

    tools {
      terraform 'terraform-0.12.28'
    }
    parameters {
      choice(name: 'ENVIRONMENT', choices: ['', 'dev', 'prod'], description: 'Pick an environment')
      booleanParam(name: 'DESTROY', defaultValue: false, description: '')
    }
    environment {

      AWX                   = credentials('AWX_ADMIN')
      AWX_COMMAND_PREFIX    ="awx --conf.host http://172.31.63.158 --conf.username ${AWX_USR} --conf.password ${AWX_PSW} -k"
      ORGANIZATION_ID       =4
      SERVICE_NAME          ="${args.SERVICE_NAME}"
      SSH                   = credentials('sshRootUserPass')
      TF_VAR_SSH_USER       = "${SSH_USR}"
      TF_VAR_SSH_PASS       = "${SSH_PSW}"
      MYSQL                 = credentials('MySQLUserPass')
      TF_VAR_MYSQL_USER     = "${MYSQL_USR}"
      TF_VAR_MYSQL_PASS     = "${MYSQL_PSW}"
      GIT                   = credentials('GitUserPass')
      TF_VAR_GIT_USER       = "${GIT_USR}"
      TF_VAR_GIT_PASS       = "${GIT_PSW}"
    }

    stages {

      stage('Load Common Scripts') {
        steps {
          dir('scripts') {
            git credentialsId: 'GitUserPass', url: 'https://gitlab.com/batch47/ansible/roboshop-project.git'
          }
        }
      }

      stage('Terraform INIT') {

        when {
          expression {
            return args.INIT
          }
        }

        steps {
          sh '''
            terraform init -backend-config=env/${ENVIRONMENT}.tfvars -no-color 
          '''
        }
      }

      stage('Terraform PLAN') {

        when {
          expression {
            return args.PLAN
          }
        }

        steps {
          sh '''
            terraform plan -var-file=env/${ENVIRONMENT}.tfvars -no-color 
          '''
        }
      }

      stage('Terraform APPLY') {

        when {
          allOf {
            expression { return args.APPLY }
            expression { DESTROY != "true" }
          }
        }

        steps {
          sh '''
            terraform get -update
            terraform apply -var-file=env/${ENVIRONMENT}.tfvars -auto-approve -no-color
          '''
        }
      }

      stage('AWX Configuration') {

        when {
          allOf {
            expression { return args.AWX }
            expression { return args.APPLY }
            expression { DESTROY != "true" }
          }
        }

        steps {
          sh '''
            sudo yum install yum-utils -y
            sudo yum-config-manager --add-repo https://releases.ansible.com/ansible-tower/cli/ansible-tower-cli-centos7.repo
            sudo yum install ansible-tower-cli -y --nogpgcheck
            terraform output >/tmp/out
            export PRIVATE_IP=$(grep ^PRIVATE_IP /tmp/out | awk '{print $NF}')
            sh scripts/scripts/awx.sh ${SERVICE_NAME} ${ENVIRONMENT}
          '''
        }
      }

      stage('Terraform DESTROY') {

        when {
          expression { DESTROY == "true" }
        }

        steps {
          sh '''
            terraform destroy -var-file=env/${ENVIRONMENT}.tfvars -auto-approve -no-color
          '''
        }
      }

    }

    post {
      always {
        cleanWs()
      }
    }

  }

}

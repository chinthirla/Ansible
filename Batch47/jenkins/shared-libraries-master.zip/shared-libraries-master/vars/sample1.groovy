def call() {
  URL1 = "google.com"
  pipeline {
    agent any
    stages {
      stage('Example') {
        steps {
          sh '''
            echo ${URL2}
          '''
          script {
            println URL2
          }
        }
      }
    }
  }


}

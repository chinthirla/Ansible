def terraformInit() {
  def execute_state=sh(returnStdout: true, script: "terraform init")
  println execute_state
}

def terraformPlan() {
  def output=sh(returnStdout: true, script: "terraform plan")
}
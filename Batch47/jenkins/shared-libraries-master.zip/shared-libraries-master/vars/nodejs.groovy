def call(Map params = [:]) {
  // Start Default Arguments
  def args = [
    APP_NAME: "null"
  ]
  args << params

  if (args.APP_NAME == "null") {
    error("APP_NAME is expected as Input from Jenkinsfile")
  }

  pipeline {
    agent {
      node {
        label 'SLAVE'
      }
    }

    tools {
      nodejs 'nodejs-12'
    }


    stages {
      stage('Install Dependencies') {
        steps {
          sh '''
            sudo yum install make gcc-c++ -y
            npm install
          '''
        }
      }

      stage('Lint Check') {
        steps {
          sh '''
            npm install --save jslint
            node_modules/jslint/bin/jslint.js --edition=latest server.js || true
            ## Clearly in companies we will not proceed if these are failure.
          '''
        }
      }

      stage('Upload Artifacts') {
        environment {
          APP_NAME = "${args.APP_NAME}"
          NEXUS=credentials('NEXUS')
        }

        steps {
          sh '''
            tar -czf ${APP_NAME}-${BUILD_NUMBER}.tar.gz node_modules server.js
            curl -f -v -u ${NEXUS_USR}:${NEXUS_PSW} --upload-file ${APP_NAME}-${BUILD_NUMBER}.tar.gz http://172.31.57.236:8081/repository/${APP_NAME}-dev/${APP_NAME}-${BUILD_NUMBER}.tar.gz
          '''
        }
      }

      stage('Deploy to DEV Env') {
        steps {
          build job: 'DEPLOY', parameters: [string(name: 'APP_NAME', value: "${args.APP_NAME}"), string(name: 'ENV', value: 'dev'), string(name: 'VERSION', value: "${BUILD_NUMBER}")]
        }
      }

    }



    post {
      always {
        cleanWs()
      }
    }

  }

}

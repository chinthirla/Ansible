def call(Map params = [:]) {
  // Start Default Arguments
  def args = [
          APP_NAME: "null",
  ]
  args << params

  if (args.APP == "null") {
    error("APP_NAME is expected as Input from Jenkinsfile")
  }

  pipeline {
    agent {
      node {
        label 'SLAVE'
      }
    }

    stages {

      stage('Lint Check') {
        steps {
          sh '''
            sudo yum install  http://rpms.remirepo.net/enterprise/remi-release-7.rpm yum-utils -y
            sudo yum-config-manager --enable remi-php73
            sudo yum -y install composer
            composer require overtrue/phplint --dev -vvv
            ./vendor/bin/phplint html
          '''
        }
      }

      stage('Upload Artifacts') {
        environment {
          APP_NAME = "${args.APP_NAME}"
          NEXUS=credentials('NEXUS')
        }

        steps {
          sh '''
            cd html
            tar -czf ${APP_NAME}-${BUILD_NUMBER}.tar.gz *
            curl -f -v -u ${NEXUS_USR}:${NEXUS_PSW} --upload-file ${APP_NAME}-${BUILD_NUMBER}.tar.gz http://172.31.57.236:8081/repository/${APP_NAME}-dev/${APP_NAME}-${BUILD_NUMBER}.tar.gz
          '''
        }
      }

      stage('Deploy to DEV Env') {
        steps {
          build job: 'DEPLOY', parameters: [string(name: 'APP_NAME', value: "${args.APP_NAME}"), string(name: 'ENV', value: 'dev'), string(name: 'VERSION', value: "${BUILD_NUMBER}")]
        }
      }

    }

    post {
      always {
        cleanWs()
      }
    }

  }

}

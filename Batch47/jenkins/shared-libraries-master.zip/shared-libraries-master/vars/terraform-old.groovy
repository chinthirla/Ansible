def AWS_CONNECTION_CHECK() {
  command="${AWX_COMMAND_PREFIX} me"
  Process process = command.execute()
  def out = new StringBuffer()
  def err = new StringBuffer()
  process.consumeProcessOutput( out, err )
  process.waitFor()
  if( err.size() > 0 ) {
    error("CONNECTON TO AWX - FAILED")
  }
}

def ADD_INVENTORY(SERVICE_NAME) {
  command="${AWX_COMMAND_PREFIX}  inventory create --name ${SERVICE_NAME} --organization ${ORGANIZATION_ID}"
  Process process = command.execute()
  def out = new StringBuffer()
  def err = new StringBuffer()
  process.consumeProcessOutput( out, err )
  process.waitFor()
  if( err.size() > 0 ) {
    error("ADDING INVENTORY ${SERVICE_NAME} - FAILED")
  }
  if( out.size() > 0 ) {
    println("ADDING INVENTORY ${SERVICE_NAME} - SUCCESS")
  }
}

def ADD_HOST(SERVICE_NAME,IP) {
  command="${AWX_COMMAND_PREFIX}  hosts create --inventory ${SERVICE_NAME} --name ${IP}"
  Process process = command.execute()
  def out = new StringBuffer()
  def err = new StringBuffer()
  process.consumeProcessOutput( out, err )
  process.waitFor()
  if( err.size() > 0 ) {
    error("ADDING HOST ${IP} - FAILED")
  }
  if( out.size() > 0 ) {
    println("ADDING HOST ${IP} - SUCCESS")
  }
}

def CHECK_HOST_EXISTS_IN_INVENTORY(SERVICE_NAME,IP) {
  command="${AWX_COMMAND_PREFIX}  hosts list  --inventory MONGODB -f human --filter name"
  Process process = command.execute() | "grep ${IP}".execute()
  def out = new StringBuffer()
  def err = new StringBuffer()
  process.consumeProcessOutput( out, err )
  process.waitFor()
  if( err.size() > 0 ) {
    error("HOST ${IP} - CHECK FAILED")
    print err
  }
  if( out.size() > 0 ) {
    println("HOST ${IP} - ALREADY EXISTS")
    println out
    return
  }
  ADD_HOST(SERVICE_NAME,IP)
}

def ADD_HOST_TO_INVENTORY(SERVICE_NAME) {
  command="${AWX_COMMAND_PREFIX}  inventory get ${SERVICE_NAME}"
  Process process = command.execute()
  def out = new StringBuffer()
  def err = new StringBuffer()
  process.consumeProcessOutput( out, err )
  process.waitFor()
  if( err.size() > 0 ) {
    println(SERVICE_NAME+  " INVENTORY - MISSING")
    ADD_INVENTORY(SERVICE_NAME)
  }
  if( out.size() > 0 ) {
    println(SERVICE_NAME+" INVENTORY - ALREADY EXIST")
  }
  String IP = new File('/tmp/ip').text.trim()
  CHECK_HOST_EXISTS_IN_INVENTORY(SERVICE_NAME,IP)
}

def RUN_TEMPLATE(SERVICE_NAME) {
  def TEMPLATE_IDS = [MONGODB: 11]
  def TEMPLATE_JOB_ID = TEMPLATE_IDS[SERVICE_NAME]
  command="${AWX_COMMAND_PREFIX} job_templates modify --id ${TEMPLATE_JOB_ID} --inventory ${SERVICE_NAME}"
  Process process = command.execute()
  def out = new StringBuffer()
  def err = new StringBuffer()
  process.consumeProcessOutput( out, err )
  println out
  println err


  command1="${AWX_COMMAND_PREFIX} job_templates launch --id ${TEMPLATE_JOB_ID}"
  Process process1 = command1.execute()
  def out1 = new StringBuffer()
  def err1 = new StringBuffer()
  process1.consumeProcessOutput( out, err )
  if( err1.size() > 0 ) {
    println err
    error ("Launch Job Template - FAILED")
  }
  if( out1.size() > 0 ) {
    println out
    println(SERVICE_NAME+" Job Template - SUCCESS")
  }
}

def call(Map params = [:]) {
  // Start Default Arguments
  def args = [
          INIT : true,
          PLAN : false,
          APPLY: true,
          DESTROY: false,
          SERVICE_NAME: "null"
  ]
  args << params

  if (args.SERVICE_NAME == "null") {
    error("SERVICE_NAME is expected as Input from Jenkinsfile")
  }

  pipeline {
    agent any
    parameters {
      choice(name: 'ENVIRONMENT', choices: ['', 'dev', 'prod'], description: 'Pick an environment')
    }
    environment {
      AWX = credentials('AWX_ADMIN')
      AWX_COMMAND_PREFIX="awx --conf.host http://172.31.51.150 --conf.username ${AWX_USR} --conf.password ${AWX_PSW} -k "
      ORGANIZATION_ID=4
    }
    stages {

      stage('Terraform INIT') {

        when {
          expression {
            return args.INIT
          }
        }

        steps {
          sh '''
            terraform init -backend-config=env/${ENVIRONMENT}.tfvars -no-color 
          '''
        }
      }

      stage('Terraform PLAN') {

        when {
          expression {
            return args.PLAN
          }
        }

        steps {
          sh '''
            terraform plan -var-file=env/${ENVIRONMENT}.tfvars -no-color 
          '''
        }
      }

      stage('Terraform APPLY') {

        when {
          expression {
            return args.APPLY
          }
        }

        steps {
          sh '''
            terraform apply -var-file=env/${ENVIRONMENT}.tfvars -auto-approve -no-color | tee /tmp/out 
            export PRIVATE_IP=$(grep ^PRIVATE_IP /tmp/out | awk '{print $NF}')
            echo ${PRIVATE_IP} >/tmp/ip
          '''
          script {
            AWS_CONNECTION_CHECK()
            ADD_HOST_TO_INVENTORY(args.SERVICE_NAME)
            RUN_TEMPLATE(args.SERVICE_NAME)
          }
        }
      }

      stage('Terraform DESTROY') {

        when {
          expression {
            return args.DESTROY
          }
        }

        steps {
          sh '''
            make destroy
          '''
        }
      }

    }
  }

}

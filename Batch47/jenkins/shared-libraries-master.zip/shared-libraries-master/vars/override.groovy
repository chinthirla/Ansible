def sample(Map params = [:]) {
  // Start Default Arguments
  def args = [
          a : 10,
          b : 20
  ]
  args << params
  println args.a+args.b
}

sample (b:100)
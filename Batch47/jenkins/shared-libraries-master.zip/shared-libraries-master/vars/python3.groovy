def call(Map params = [:]) {
  // Start Default Arguments
  def args = [
          APP_NAME: "null",
  ]
  args << params

  if (args.APP == "null") {
    error("APP_NAME is expected as Input from Jenkinsfile")
  }

  pipeline {
    agent {
      node {
        label 'SLAVE'
      }
    }

    tools {
      go 'go1.14'
    }


    stages {

      stage('Lint Check') {
        steps {
          sh '''
            sudo yum install pylint -y
            pylint *.py || true
          '''
        }
      }

      stage('Upload Artifacts') {
        environment {
          APP_NAME = "${args.APP_NAME}"
          NEXUS=credentials('NEXUS')
        }

        steps {
          sh '''
            tar -czf ${APP_NAME}-${BUILD_NUMBER}.tar.gz payment.py payment.ini rabbitmq.py requirements.txt
            curl -f -v -u ${NEXUS_USR}:${NEXUS_PSW} --upload-file ${APP_NAME}-${BUILD_NUMBER}.tar.gz http://3.227.239.212:8081/repository/${APP_NAME}-dev/${APP_NAME}-${BUILD_NUMBER}.tar.gz
          '''
        }
      }

    }

    post {
      always {
        cleanWs()
      }
    }

  }

}

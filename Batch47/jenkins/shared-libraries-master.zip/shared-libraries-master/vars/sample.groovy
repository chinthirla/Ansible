def info(message) {
  echo "INFO: ${message}"
}

def warning(message) {
  echo "WARNING: ${message}"
}

def addF(a,b) {
  println a+b
}



def call() {
  URL1 = "google.com"
  def command = "echo Hello"
  def proc = command.execute()
  proc.waitFor()

  println "Process exit code: ${proc.exitValue()}"
  println "Std Err: ${proc.err.text}"
  println "Std Out: ${proc.in.text}"

  a=100   // Number
  b="abc" // String
  c=true

  println "a =  ${a}"
  println "b = "+ b
  println c

  addF(10,80)

}

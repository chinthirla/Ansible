def call(PLANRUN=true) {
  pipeline {
    agent any
    stages {
      stage('INIT') {
        steps {
          sh '''
          terraform init
        '''
        }
      }

      stage('PLAN') {
        when {
          expression {
            return PLANRUN
          }
        }
        steps {
         sh '''
          terraform plan
          '''
        }
      }

    }
  }
}
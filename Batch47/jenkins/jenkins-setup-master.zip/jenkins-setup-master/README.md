# jenkins-setup

After Creating Jenkins Instance.

1. Configure Seed Job 
2. Configure Authorize Plugin 

3. Install Terraform 
```
# labauto
```
4. Install awx cli 

```text
# yum-config-manager --add-repo https://releases.ansible.com/ansible-tower/cli/ansible-tower-cli-centos7.repo
# yum install ansible-tower-cli -y --nogpgcheck
```

5. Test connection 

```text
awx --conf.host http://172.31.51.150 \
    --conf.username admin --conf.password password \
    --conf.insecure \
    users list
```

AWS Steps.
1. Delete old inventory / Delete the host in inventory 
2. Create inventory  -> this can be skipped
3. Create host inside that 
4. Run the template.


```yaml
apiVersion: xxxx 
kind:  xxxx
metadata:
  xxxxxxx
spec:
  xxxxxxx
```

To get list of api versions,

```bash
kubectl api-versions
```

To get list of kind of resources

```bash 
kubectl api-resources
```

metatadata will have the name of a resource

spec will a `Pod Spec` if you write for pod, will be `replicaset spec` if we create replicaset and so on.


But these four key words are very mandatory for most of the resources.


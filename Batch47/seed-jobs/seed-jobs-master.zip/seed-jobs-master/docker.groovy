// Directories
folder('DOCKER') {
  displayName('DOCKER')
  description('CI Jobs Using Docker')
}



pipelineJob("DOCKER/cart") {
  description('DOCKER Cart Service')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/robot-shop/cart.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile-docker")
    }
  }
}

pipelineJob("DOCKER/catalogue") {
  description('DOCKER Catalogue Service')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/robot-shop/catalogue.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile-docker")
    }
  }
}

pipelineJob("DOCKER/user") {
  description('DOCKER User Service')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/robot-shop/user.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile-docker")
    }
  }
}

pipelineJob("DOCKER/dispatch") {
  description('DOCKER Dispatch Service')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/robot-shop/dispatch.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile-docker")
    }
  }
}

pipelineJob("DOCKER/frontend") {
  description('DOCKER Frontend Service')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/robot-shop/frontend.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile-docker")
    }
  }
}

pipelineJob("DOCKER/payment") {
  description('DOCKER Payment Service')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/robot-shop/payment.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile-docker")
    }
  }
}

pipelineJob("DOCKER/ratings") {
  description('DOCKER Ratings Service')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/robot-shop/ratings.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile-docker")
    }
  }
}

pipelineJob("DOCKER/shipping") {
  description('DOCKER Shipping Service')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/robot-shop/shipping.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile-docker")
    }
  }
}

pipelineJob("DOCKER/mysql") {
  description('DOCKER MySQL JOb Service')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/robot-shop/mysql.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile-docker")
    }
  }
}


pipelineJob("DOCKER/mongodb") {
  description('DOCKER Mongodb JOb Service')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/robot-shop/mongodb.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile-docker")
    }
  }
}
pipelineJob("DEPLOY") {
  description('DEPLOY Job')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/jenkins/shared-libraries.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile-deployment")
    }
  }
}


pipelineJob("Promote-to-PROD") {
  description('Promote-to-PROD Job')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/terraform/test-infra.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile")
    }
  }
}


pipelineJob("Promote-to-Kubernetes-PROD") {
  description('Promote-to-Kubernetes-PROD Job')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/kubernetes.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile")
    }
  }
}

pipelineJob("Promote-to-Kubernetes-PROD-BlueGreen") {
  description('Promote-to-Kubernetes-PROD BlueGreen Job')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/kubernetes.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile-bg")
    }
  }
}
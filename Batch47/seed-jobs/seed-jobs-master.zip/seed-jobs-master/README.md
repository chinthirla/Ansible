# seed-jobs

Seed jobs  can be created in a easy way is 
    1. Create a job manually with all the options ( Just for Once
    2. Convert that job into seed job code, We can use this code as template.
    
    How to do this :
     1. Plugin "XML Job to Job DSL"
     2. https://github.com/rsacramento18/jenkinsxml2jobdsl
     

```text
https://www.pylint.org/#install
https://www.npmjs.com/package/jslint
https://maven.apache.org/plugins/maven-checkstyle-plugin/
https://github.com/golang/lint
https://github.com/overtrue/phplint
```
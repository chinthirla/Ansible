// Directories
folder('Terraform') {
  displayName('Terraform')
  description('Terraform Jobs')
}



// VPC
pipelineJob("Terraform/VPC") {
  description('Terraform VPC Job')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/terraform/roboshop/vpc.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile")
    }
  }
}


pipelineJob("Terraform/MongoDB") {
  description('Terraform MongoDB Job')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/terraform/roboshop/mongodb.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile")
    }
  }
}

pipelineJob("Terraform/MySQL") {
  description('Terraform MySQL Job')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/terraform/roboshop/mysql.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile")
    }
  }
}

pipelineJob("Terraform/Route53") {
  description('Terraform Route53 Job')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/terraform/roboshop/route53.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile")
    }
  }
}

pipelineJob("Terraform/Redis") {
  description('Terraform Redis Job')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/terraform/roboshop/redis.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile")
    }
  }
}

pipelineJob("Terraform/RabbitMQ") {
  description('Terraform RabbitMQ Job')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/terraform/roboshop/rabbitmq.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile")
    }
  }
}

pipelineJob("Terraform/Cart") {
  description('Terraform Cart Services Job')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/terraform/roboshop/cart.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile")
    }
  }
}

pipelineJob("Terraform/Catalogue") {
  description('Terraform Catalogue Services Job')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/terraform/roboshop/catalogue.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile")
    }
  }
}

pipelineJob("Terraform/User") {
  description('Terraform User Services Job')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/terraform/roboshop/user.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile")
    }
  }
}


pipelineJob("Terraform/Payment") {
  description('Terraform Payment Services Job')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/terraform/roboshop/payment.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile")
    }
  }
}

pipelineJob("Terraform/Shipping") {
  description('Terraform Shipping Services Job')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/terraform/roboshop/shipping.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile")
    }
  }
}

pipelineJob("Terraform/Dispatch") {
  description('Terraform Dispatch Services Job')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/terraform/roboshop/dispatch.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile")
    }
  }
}

pipelineJob("Terraform/Ratings") {
  description('Terraform Ratings Services Job')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/terraform/roboshop/ratings.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile")
    }
  }
}

pipelineJob("Terraform/Frontend") {
  description('Terraform Frontend Services Job')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/terraform/roboshop/frontend.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile")
    }
  }
}


pipelineJob("Terraform/ALB") {
  description('Terraform ALB Services Job')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/terraform/roboshop/load-balancer.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile")
    }
  }
}



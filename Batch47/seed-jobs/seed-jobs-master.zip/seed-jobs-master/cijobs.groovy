// Directories
folder('CIJOBS') {
  displayName('CIJOBS')
  description('CI Jobs')
}



pipelineJob("CIJOBS/cart") {
  description('CIJOB Cart Service')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/robot-shop/cart.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile")
    }
  }
}

pipelineJob("CIJOBS/catalogue") {
  description('CIJOB Catalogue Service')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/robot-shop/catalogue.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile")
    }
  }
}

pipelineJob("CIJOBS/user") {
  description('CIJOB User Service')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/robot-shop/user.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile")
    }
  }
}

pipelineJob("CIJOBS/dispatch") {
  description('CIJOB Dispatch Service')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/robot-shop/dispatch.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile")
    }
  }
}

pipelineJob("CIJOBS/frontend") {
  description('CIJOB Frontend Service')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/robot-shop/frontend.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile")
    }
  }
}

pipelineJob("CIJOBS/payment") {
  description('CIJOB Payment Service')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/robot-shop/payment.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile")
    }
  }
}

pipelineJob("CIJOBS/ratings") {
  description('CIJOB Ratings Service')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/robot-shop/ratings.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile")
    }
  }
}

pipelineJob("CIJOBS/shipping") {
  description('CIJOB Shipping Service')
  definition {
    cpsScm {
      scm {
        git {
          remote {
            url("https://gitlab.com/batch47/robot-shop/shipping.git")
            credentials("GitUserPass")
          }
          branch("*/master")
        }
      }
      scriptPath("Jenkinsfile")
    }
  }
}
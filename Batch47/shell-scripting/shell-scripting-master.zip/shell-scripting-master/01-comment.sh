#!/bin/bash

# Any Line starts with # character is treated as comment by any interpreter along with BASH shell.

## Single hash or any hashes does not really matter, If it starts with single hash that is a comment

## How to do multi line commenting.

<<COMMENT
ls
pwd
uname
cat /etc/*release
COMMENT

## One moore line ##
#!/bin/bash

## Taking input from user can be done by using read command

read -p 'Enter Your Name: ' name


echo -e "Hello $name, Welcome to DevOps Training"

## This read command cannot be used in automation